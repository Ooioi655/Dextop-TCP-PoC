package com.mahan.dextopreceiver

import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Bundle
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.app.Activity
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var host: EditText
    private lateinit var port: EditText
    private lateinit var status: TextView
    private lateinit var surfaceView: SurfaceView
    private var receiver: Receiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.mahan.dextopreceiver.R.layout.activity_main)
        host = findViewById(R.id.host)
        port = findViewById(R.id.port)
        status = findViewById(R.id.status)
        surfaceView = findViewById(R.id.surface)
        surfaceView.holder.addCallback(this)
        findViewById<Button>(R.id.start).setOnClickListener {
            receiver?.stop()
            val h = host.text.toString().trim()
            val p = port.text.toString().toIntOrNull() ?: 47821
            receiver = Receiver(h, p, surfaceView.holder.surface).also { it.start() }
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) { receiver?.stop(); receiver = null }
    override fun onDestroy() { receiver?.stop(); receiver = null; super.onDestroy() }

    private fun setStatus(value: String) = runOnUiThread { status.text = value }

    private inner class Receiver(private val host: String, private val port: Int, private val surface: Surface) {
        private val running = AtomicBoolean(true)
        private var socket: Socket? = null
        private var codec: MediaCodec? = null

        fun start() = Thread({ run() }, "DextopReceiver").start()

        fun stop() {
            running.set(false)
            runCatching { socket?.close() }
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            codec = null
        }

        private fun run() {
            try {
                setStatus("Connecting to $host:$port …")
                val s = Socket(host, port)
                socket = s
                s.tcpNoDelay = true
                val input = DataInputStream(BufferedInputStream(s.getInputStream(), 64 * 1024))
                while (running.get()) {
                    val magic = ByteArray(4); input.readFully(magic)
                    if (!magic.contentEquals(byteArrayOf(68,88,84,83))) error("Bad D X T S header")
                    val version = input.readUnsignedByte()
                    if (version != 1) error("Unsupported protocol version $version")
                    when (val type = input.readUnsignedByte()) {
                        1 -> configure(input)
                        2 -> decodeFrame(input)
                        3 -> break
                        else -> error("Unknown packet $type")
                    }
                }
            } catch (t: Throwable) {
                if (running.get()) setStatus("Error: ${t.message}")
            } finally {
                runCatching { socket?.close() }
                socket = null
                runCatching { codec?.stop() }
                runCatching { codec?.release() }
                codec = null
                if (running.get()) setStatus("Disconnected")
            }
        }

        private fun configure(input: DataInputStream) {
            val width = input.readInt(); val height = input.readInt(); val fps = input.readInt()
            val csd0 = ByteArray(input.readInt()); input.readFully(csd0)
            val csd1 = ByteArray(input.readInt()); input.readFully(csd1)
            runCatching { codec?.stop(); codec?.release() }
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setByteBuffer("csd-0", java.nio.ByteBuffer.wrap(csd0))
                setByteBuffer("csd-1", java.nio.ByteBuffer.wrap(csd1))
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            }
            val decoder = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            decoder.configure(format, surface, null, 0)
            decoder.start()
            codec = decoder
            setStatus("Connected — ${width}x${height} @ ${fps}fps")
        }

        private fun decodeFrame(input: DataInputStream) {
            val key = input.readUnsignedByte() != 0
            val ptsUs = input.readLong()
            val size = input.readInt()
            require(size in 1..8_000_000) { "Invalid frame size $size" }
            val data = ByteArray(size); input.readFully(data)
            val decoder = codec ?: return
            var index = decoder.dequeueInputBuffer(5_000)
            if (index < 0) {
                // Drop this access unit when the decoder is saturated. The next
                // keyframe will recover because the sender emits one every second.
                return
            }
            val buffer = decoder.getInputBuffer(index) ?: return
            buffer.clear(); buffer.put(data)
            decoder.queueInputBuffer(index, 0, data.size, ptsUs, 0)
            val info = MediaCodec.BufferInfo()
            while (true) {
                val out = decoder.dequeueOutputBuffer(info, 0)
                if (out >= 0) decoder.releaseOutputBuffer(out, true) else break
            }
        }
    }
}

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.mahan.dextopreceiver"; compileSdk = 36
    defaultConfig { applicationId = "com.mahan.dextopreceiver"; minSdk = 30; targetSdk = 36; versionCode = 1; versionName = "0.1" }
}

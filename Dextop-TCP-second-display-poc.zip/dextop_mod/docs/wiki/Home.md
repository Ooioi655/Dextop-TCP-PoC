# Dextop Wiki

<p align="center">
  <a href="https://github.com/NarYuki/Dextop/releases/latest"><img src="https://raw.githubusercontent.com/NarYuki/Dextop/main/docs/media/get-it-on-github.png" alt="Get it on GitHub" height="56"></a>
  <a href="https://play.google.com/store/apps/details?id=moe.n4tsu.gpdextop"><img src="https://raw.githubusercontent.com/NarYuki/Dextop/main/docs/media/get-it-on-google-play.png" alt="Get it on Google Play" height="56"></a>
</p>

Dextop creates a controllable virtual desktop display on Android using its built-in privileged access runtime and Android system services. From version 1.5.0 onward, including the latest release, no external app is required: normal setup can be completed with Dextop alone. If root, Stellar, Shizuku, or another compatible privileged service is already available, Dextop detects it and adapts automatically.

The production release is available from [Google Play](https://play.google.com/store/apps/details?id=moe.n4tsu.gpdextop). Signed APKs and release assets remain available from [GitHub Releases](https://github.com/NarYuki/Dextop/releases/latest).

Current versions: **Dextop 1.7.0**, **Dextop・Parking 2.0.0**, and **Dextop・Driving 2.0.0**.

## User documentation

- [Installation and initial setup](Installation-and-Setup)
- [Using Dextop](Using-Dextop)
- [Android Auto and Dextop Car Companion](Android-Auto)
- [Features and settings](Features-and-Settings)
- [Input and gestures](Input-and-Gestures)
- [Diagnostics and recovery](Diagnostics-and-Recovery)
- [Device reports](Device-Reports)
- [Restore Android with ADB](ADB-System-Recovery)
- [Compatibility](Compatibility)

## Contributor documentation

- [Development and contributions](Development-and-Contributions)
- [Adding device support](https://github.com/NarYuki/Dextop/blob/main/docs/ADDING_DEVICE_SUPPORT.en.md)
- [Issue tracker](https://github.com/NarYuki/Dextop/issues)

English is the primary project language. Japanese translations may be added as supplementary documentation.

package moe.n4tsu.dextop

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

/** Small test UI for the Android-to-Android TCP second-display prototype. */
class DextopTcpStreamActivity : Activity() {
    private var running = false
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.BLACK)
        }
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            text = "TCP Display: stopped"
            gravity = Gravity.CENTER
        }
        val start = Button(this).apply { text = "Start TCP display stream" }
        val stop = Button(this).apply { text = "Stop" }
        root.addView(status, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(start)
        root.addView(stop)
        setContentView(root)

        start.setOnClickListener {
            MirrorService.startTcpDisplayStream().onSuccess { url ->
                running = true
                status.text = "Receiver address:\n$url\n\nOpen Dextop TCP Receiver on T290 and connect to the IP/port above."
            }.onFailure { error ->
                status.text = "Start failed:\n${error.message}"
            }
        }
        stop.setOnClickListener {
            MirrorService.stopTcpDisplayStream()
            running = false
            status.text = "TCP Display: stopped"
        }
    }

    override fun onDestroy() {
        if (isFinishing && running) MirrorService.stopTcpDisplayStream()
        super.onDestroy()
    }
}

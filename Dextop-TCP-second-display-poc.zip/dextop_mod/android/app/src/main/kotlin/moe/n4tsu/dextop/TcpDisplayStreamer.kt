package moe.n4tsu.dextop

import android.content.Context
import android.hardware.display.DisplayManager
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.view.Surface
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

/** Dextop virtual-display -> H.264 -> TCP proof-of-concept sender. */
internal class TcpDisplayStreamer(
    private val context: Context,
    private val privilegedAccess: PrivilegedAccess,
    private val sourceDisplayId: Int,
    sourceWidth: Int,
    sourceHeight: Int,
    private val density: Int,
    private val port: Int = 47821
) {
    companion object {
        private val MAGIC = byteArrayOf('D'.code.toByte(), 'X'.code.toByte(), 'T'.code.toByte(), 'S'.code.toByte())
        private const val VERSION = 1
        private const val CONFIG = 1
        private const val FRAME = 2
        private const val EOS = 3
        private const val FPS = 30
        private const val BITRATE = 6_000_000
    }

    private val running = AtomicBoolean(false)
    private val executor = Executors.newCachedThreadPool { task ->
        Thread(task, "Dextop-tcp-display").apply { isDaemon = true }
    }
    private val backend = DisplayMirrorBackend(
        context, context.contentResolver,
        context.getSystemService(DisplayManager::class.java),
        privilegedAccess, DesktopEnvironmentRegistry.current()
    )
    private val width: Int
    private val height: Int
    private var codec: MediaCodec? = null
    private var codecSurface: Surface? = null
    private var server: ServerSocket? = null
    @Volatile private var client: Socket? = null
    @Volatile private var output: DataOutputStream? = null
    @Volatile private var csd0: ByteArray? = null
    @Volatile private var csd1: ByteArray? = null

    init {
        val scale = (1280f / maxOf(sourceWidth, sourceHeight).coerceAtLeast(1)).coerceAtMost(1f)
        width = even((sourceWidth * scale).roundToInt()).coerceAtLeast(320)
        height = even((sourceHeight * scale).roundToInt()).coerceAtLeast(240)
    }

    fun start(): String {
        check(running.compareAndSet(false, true)) { "TCP display stream is already running" }
        server = ServerSocket(port).also { it.reuseAddress = true }
        executor.execute { acceptClients(server!!) }
        startEncoder()
        val address = localIpv4Address() ?: error("No local IPv4 address is available")
        return "tcp://$address:$port"
    }

    fun stop() {
        if (!running.compareAndSet(true, false)) return
        runCatching { server?.close() }
        closeClient()
        runCatching { backend.releaseLayer() }
        runCatching { codec?.signalEndOfInputStream() }
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        runCatching { codecSurface?.release() }
        executor.shutdownNow()
    }

    private fun startEncoder() {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setFloat(MediaFormat.KEY_I_FRAME_INTERVAL, 1f)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
            setInteger(MediaFormat.KEY_PRIORITY, 0)
            setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
            if (android.os.Build.VERSION.SDK_INT >= 30) setInteger(MediaFormat.KEY_LATENCY, 0)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val input = encoder.createInputSurface()
        codec = encoder
        codecSurface = input
        encoder.start()
        backend.attachSurface(sourceDisplayId, input, width, height, width, height, density.coerceAtLeast(1))
        executor.execute { drainEncoder(encoder) }
    }

    private fun drainEncoder(encoder: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running.get()) {
                when (val index = encoder.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = encoder.outputFormat
                        csd0 = f.getByteBuffer("csd-0")?.let(::copyBuffer)
                        csd1 = f.getByteBuffer("csd-1")?.let(::copyBuffer)
                        sendConfig()
                    }
                    else -> if (index >= 0) {
                        val buffer = encoder.getOutputBuffer(index)
                        if (buffer != null && info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            val data = copyBuffer(buffer, info.offset, info.size)
                            sendFrame(info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0, data)
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) sendEos()
                        encoder.releaseOutputBuffer(index, false)
                    }
                }
            }
        } catch (t: Throwable) {
            if (running.get()) OperationLog.e(context, "TcpDisplay", "encoder failed", t)
        }
    }

    private fun acceptClients(socket: ServerSocket) {
        while (running.get()) {
            val incoming = runCatching { socket.accept() }.getOrNull() ?: break
            executor.execute { serveClient(incoming) }
        }
    }

    private fun serveClient(incoming: Socket) {
        incoming.use { s ->
            s.tcpNoDelay = true
            s.keepAlive = true
            synchronized(this) {
                closeClientLocked()
                client = s
                output = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 32 * 1024))
                sendConfigLocked()
            }
            try { while (running.get() && s.inputStream.read() >= 0) Unit } catch (_: IOException) {}
            synchronized(this) { if (client === s) closeClientLocked() }
        }
    }

    @Synchronized private fun sendConfig() = sendConfigLocked()
    private fun sendConfigLocked() {
        val out = output ?: return
        val a = csd0 ?: return
        val b = csd1 ?: return
        runCatching {
            out.write(MAGIC); out.writeByte(VERSION); out.writeByte(CONFIG)
            out.writeInt(width); out.writeInt(height); out.writeInt(FPS)
            out.writeInt(a.size); out.write(a); out.writeInt(b.size); out.write(b); out.flush()
        }.onFailure { closeClientLocked() }
    }

    @Synchronized private fun sendFrame(ptsUs: Long, key: Boolean, data: ByteArray) {
        val out = output ?: return
        runCatching {
            out.write(MAGIC); out.writeByte(VERSION); out.writeByte(FRAME)
            out.writeByte(if (key) 1 else 0); out.writeLong(ptsUs); out.writeInt(data.size); out.write(data); out.flush()
        }.onFailure { closeClientLocked() }
    }

    @Synchronized private fun sendEos() {
        val out = output ?: return
        runCatching { out.write(MAGIC); out.writeByte(VERSION); out.writeByte(EOS); out.flush() }
            .onFailure { closeClientLocked() }
    }

    private fun closeClient() { synchronized(this) { closeClientLocked() } }
    private fun closeClientLocked() {
        runCatching { output?.close() }; runCatching { client?.close() }
        output = null; client = null
    }

    private fun copyBuffer(source: ByteBuffer): ByteArray {
        val b = source.duplicate(); val out = ByteArray(b.remaining()); b.get(out); return out
    }
    private fun copyBuffer(source: ByteBuffer, offset: Int, size: Int): ByteArray {
        val b = source.duplicate(); b.position(offset); b.limit(offset + size); val out = ByteArray(size); b.get(out); return out
    }
    private fun localIpv4Address(): String? = NetworkInterface.getNetworkInterfaces().toList().asSequence()
        .filter { it.isUp && !it.isLoopback }.flatMap { it.inetAddresses.toList().asSequence() }
        .filterIsInstance<Inet4Address>().firstOrNull { !it.isLoopbackAddress && it.isSiteLocalAddress }?.hostAddress
    private fun even(value: Int): Int = value and 1.inv()
}
